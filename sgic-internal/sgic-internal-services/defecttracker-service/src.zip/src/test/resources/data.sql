create schema if not exists defectservices;
