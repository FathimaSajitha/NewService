package com.sgic.internal.defecttracker.defect.entities;

public class Defect {

}
