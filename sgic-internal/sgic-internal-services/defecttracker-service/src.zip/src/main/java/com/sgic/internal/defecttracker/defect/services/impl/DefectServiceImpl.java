package com.sgic.internal.defecttracker.defect.services.impl;

public class DefectServiceImpl {

}
