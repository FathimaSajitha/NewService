package com.sgic.internal.defecttracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DefectTrackerApplication 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(DefectTrackerApplication.class, args);
    }
}
