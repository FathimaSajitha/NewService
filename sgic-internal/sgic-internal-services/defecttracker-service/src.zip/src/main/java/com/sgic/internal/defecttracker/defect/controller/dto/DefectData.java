package com.sgic.internal.defecttracker.defect.controller.dto;

public class DefectData {

}
