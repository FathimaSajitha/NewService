package com.sgic.internal.defecttracker.defect.services;

public interface DefectService {

}
