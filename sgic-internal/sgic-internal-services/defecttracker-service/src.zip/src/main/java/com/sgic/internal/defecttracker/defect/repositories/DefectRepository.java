package com.sgic.internal.defecttracker.defect.repositories;

public interface DefectRepository {

}
