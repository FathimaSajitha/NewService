package com.sgic.internal.defecttracker.defect.controller;

public class DefectController {

}
